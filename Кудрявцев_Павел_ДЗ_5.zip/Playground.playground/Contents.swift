import Foundation

import Foundation

enum CarType { case trunk,  speedcar }
enum DoorState { case close, open }
enum EngineState { case on, off }

protocol Car{
    var cartype: CarType {get set}
    var doorstate: DoorState {get set}
    var enginestate: EngineState {get set}
    func Action(_ mode: Bool) // в классах будет метод, одновременно оперирующий и дверями и двигателем
    func Typed(_ name: String) // функция вывода на печать
   }
extension Car {
     func Engine(_ mode: Bool){} // планируем добавить метод управления исключительно двигателем
     func Doors(_ mode: Bool){} // метод, работающий только с дверями
}

class TrunkCar: Car{
    var cartype: CarType
    var doorstate: DoorState
    var enginestate: EngineState

    init (cartype: CarType, doorstate: DoorState, enginestate: EngineState){
        self.cartype = cartype; self.doorstate = doorstate; self.enginestate = enginestate;
    }
    
     func Action(_ mode: Bool){
         if (mode) { doorstate = .close; enginestate = .on;}
         else { doorstate = .open; enginestate = .off;}
     }

func Typed(_ name: String){
   print (name," Тип: ",cartype," Двери: ",doorstate,", Двигатель: ",enginestate)
}}

extension TrunkCar { 
    func Engine(_ mode: Bool){
    if (mode) {enginestate = .on;} else {enginestate = .off;}}
    func Doors(_ mode: Bool ){
    if (mode) {doorstate = .close;} else {doorstate = .open;}}
}

///////// чтобы сократить код, унаследуемся от цистерны и добавим спортивности, а именно спойлер.
class SportCar: TrunkCar{
    let spoiler: Bool
    init (cartype: CarType, doorstate: DoorState, enginestate: EngineState,spoiler: Bool) {
    self.spoiler = spoiler
    super.init(cartype: cartype, doorstate: doorstate, enginestate: enginestate)
 }
    override func Typed(_ name: String) { 
    print (name," Тип: ",cartype," Двери: ",doorstate,", Двигатель: ",enginestate,". А еще у нее есть спойлер!")
      }
}
// логично, что расширение класса также наследуется :)
///////////////////

extension TrunkCar: CustomStringConvertible{  // имплементируем протокол для вывода в консоль
    var description: String {
        return "(Вывод через CustomStringConvertible  ЦИСТЕРНА. Тип: \(cartype), Двери: \(doorstate), Мотор: \(enginestate), Спойлера нет)"
    }
}

extension SportCar: CustomStringConvertible{  // имплементируем протокол для вывода в консоль
var description: String {
    return "(Вывод через CustomStringConvertible СпортКАР. Тип: \(cartype), Двери: \(doorstate), Мотор: \(enginestate), Спойлер в наличии!)"
    }
}








/////////////
var car1 = TrunkCar(cartype: .trunk, doorstate: .open, enginestate: .off)
var car2 = SportCar(cartype: .speedcar, doorstate: .open, enginestate: .off, spoiler: true)


print (car1)
print (car2)

print("Исходное состояние: двери открыты, двигатели выключены:")
car1.Typed("Volvo Trunk"); car2.Typed("Ferrari");
print("")

print("Работаем с первым методом - одновременно закрываем двери и запускаем моторы")
car1.Action(true); car2.Action(true); car1.Typed("Volvo Trunk");car2.Typed("Ferrari");
print("")

print("Просто выключаем моторы, не трогая двери")
car1.Engine(false); car2.Engine(false); car1.Typed("Volvo Trunk");car2.Typed("Ferrari");
print("")

print("Открываем двери (моторы уже выключены ранее)")
car1.Doors(false);car2.Doors(false);car1.Typed("Volvo Trunk");car2.Typed("Ferrari");

